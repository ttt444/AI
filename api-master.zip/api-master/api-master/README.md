# Bangumi API

开始使用 API 前，请至 [Bangumi 开发者平台](https://bgm.tv/dev/app) 创建应用。

欢迎 PR 提供更详细的文档描述或格式优化。
